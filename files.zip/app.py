import streamlit as st
from ultralytics import YOLO
from PIL import Image
import numpy as np
import cv2
import os
import gdown

st.set_page_config(
    page_title="Fruit Detection App",
    page_icon="🍎",
    layout="wide"
)

st.title("🍎🍌🍊 Fruit Object Detection")
st.write("Upload an image to detect apples, bananas, and oranges!")

# ─── Load Model ───────────────────────────────────────────────────────────────
@st.cache_resource
def load_model():
    model_path = "fruit_detection_model.pt"
    if not os.path.exists(model_path):
        with st.spinner("⬇️ Downloading model... please wait"):
            file_id = "1p4UdfbdlAOnBQA5eQCPE25b2JwX6XT5n"
            url = f"https://drive.google.com/uc?id={file_id}"
            gdown.download(url, model_path, quiet=False)
    model = YOLO(model_path)
    return model

try:
    model = load_model()
    st.success("✅ Model loaded successfully!")
except Exception as e:
    st.error(f"❌ Error loading model: {e}")
    st.stop()

# ─── Upload Image ─────────────────────────────────────────────────────────────
uploaded_file = st.file_uploader("Choose an image...", type=['jpg', 'jpeg', 'png'])

if uploaded_file is not None:
    image = Image.open(uploaded_file)

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("📷 Original Image")
        st.image(image, use_container_width=True)

    with st.spinner('🔍 Detecting fruits...'):
        results = model.predict(image, conf=0.25)
        annotated_image = results[0].plot()
        annotated_image = cv2.cvtColor(annotated_image, cv2.COLOR_BGR2RGB)

    with col2:
        st.subheader("✅ Detection Results")
        st.image(annotated_image, use_container_width=True)

    # ─── Detection Details ────────────────────────────────────────────────────
    st.subheader("📊 Detection Details")
    detections = results[0].boxes
    class_names = ['apple', 'banana', 'orange']

    if len(detections) > 0:
        for i, box in enumerate(detections):
            cls = int(box.cls[0])
            conf = float(box.conf[0])
            st.write(f"**Object {i+1}:** {class_names[cls].capitalize()} — Confidence: {conf:.2%}")
    else:
        st.warning("⚠️ No fruits detected in the image. Try another image!")

else:
    st.info("👆 Please upload an image to get started.")
